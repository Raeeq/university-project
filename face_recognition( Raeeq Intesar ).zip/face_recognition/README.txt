# Face Recognition System (Real-Time via Webcam)

This project is a Python-based real-time face recognition system using OpenCV's Haar cascade face detector and LBPH face recognizer. It captures frames from your webcam, detects faces, and recognizes individuals based on pre-trained images.

---

## 📁 Project Structure

E:/face_recognition/
├── haarcascade_frontalface_default.xml
├── face_recognizer.py
└── known_faces/
├── """Y"/
│ ├── 1.jpg
│ └── 2.jpg
└── "X"/
├── 1.jpg
└── 2.jpg
---

## Requirements

Install the required packages using `pip`:

# bash
pip install opencv-contrib-python numpy


## Prepare training images:

.Create a folder named known_faces inside the project directory.

.Add one subfolder per person (e.g., Alice, Bob), each containing at least one clear photo of their face.

.Ensure each image contains only one front-facing face.


### Notes ####

.If your webcam doesn’t work on device ID 0 but the code runs okey, try changing "cv2.VideoCapture(0)" to "cv2.VideoCapture(1)" in 5th cell line-1 .

.The LBPH recognizer works best with grayscale, front-facing face images.

.Confidence values are used to determine match quality — lower values indicate stronger matches.


Developed with OpenCV and Python by Raeeq Intesar .

This project is open-source and freely available for academic or personal use.
